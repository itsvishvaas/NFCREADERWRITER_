package com.ontap.R

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.nio.charset.Charset
import java.util.*

class MainActivity : AppCompatActivity() {

    private var nfcAdapter: NfcAdapter? = null
    private lateinit var statusText: TextView
    private var messageToWrite: NdefMessage? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        val writeTextButton = findViewById<Button>(R.id.writeTextButton)
        val writeVCardButton = findViewById<Button>(R.id.writeVCardButton)

        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null) {
            Toast.makeText(this, "NFC not supported", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        writeTextButton.setOnClickListener {
            val text = "Hello from Ontap!"
            messageToWrite = createTextMessage(text)
            statusText.text = "Tap an NFC tag to write text..."
        }

        writeVCardButton.setOnClickListener {
            val vCard = """
                BEGIN:VCARD
                VERSION:3.0
                N:John;Doe;;;
                FN:John Doe
                ORG:Ontap Inc.
                TITLE:Software Engineer
                TEL;TYPE=WORK,VOICE:(111) 555-1212
                EMAIL:john.doe@ontap.com
                END:VCARD
            """.trimIndent()
            messageToWrite = createTextMessage(vCard)
            statusText.text = "Tap an NFC tag to write business card..."
        }
    }

    override fun onResume() {
        super.onResume()
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE
        } else {
            0
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, flags)
        val filters = arrayOf(IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED))
        nfcAdapter?.enableForegroundDispatch(this, pendingIntent, filters, null)
    }

    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (messageToWrite == null) {
            statusText.text = "No data to write. Please choose an option."
            return
        }

        val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)
        if (tag != null) {
            writeMessageToTag(messageToWrite!!, tag)
        }
    }

    private fun createTextMessage(text: String): NdefMessage {
        val lang = "en"
        val langBytes = lang.toByteArray(Charset.forName("US-ASCII"))
        val textBytes = text.toByteArray(Charset.forName("UTF-8"))
        val payload = ByteArray(1 + langBytes.size + textBytes.size)
        payload[0] = langBytes.size.toByte()
        System.arraycopy(langBytes, 0, payload, 1, langBytes.size)
        System.arraycopy(textBytes, 0, payload, 1 + langBytes.size, textBytes.size)
        val record = NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, ByteArray(0), payload)
        return NdefMessage(arrayOf(record))
    }

    private fun writeMessageToTag(message: NdefMessage, tag: Tag) {
        try {
            val ndef = Ndef.get(tag)
            if (ndef != null) {
                ndef.connect()
                if (!ndef.isWritable) {
                    statusText.text = "Tag is read-only!"
                    return
                }
                if (ndef.maxSize < message.toByteArray().size) {
                    statusText.text = "Tag doesn't have enough space!"
                    return
                }
                ndef.writeNdefMessage(message)
                ndef.close()
                statusText.text = "Write successful!"
                messageToWrite = null
            } else {
                statusText.text = "NDEF is not supported by this tag!"
            }
        } catch (e: Exception) {
            statusText.text = "Write failed: ${e.message}"
        }
    }
}
